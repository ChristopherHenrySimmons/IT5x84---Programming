﻿// Exercise 14.9 Solution: FuzzyDiceForm.cs
// Application that allows user to order fuzzy dice,
// specifying the type and amount of dice.
using System;
using System.Windows.Forms;

namespace FuzzyDice
{
   public partial class FuzzyDiceForm : Form
   {
      // constructor
      public FuzzyDiceForm()
      {
         InitializeComponent();
      } // end constructor

      private void whiteBlackTextBox_TextChanged(
         object sender, EventArgs e )
      {
         // store quantity entered as int
         int numberOfWhiteBlack = Convert.ToInt32( 
            whiteBlackTextBox.Text );

         // display message if user tries to enter a value
         // without selecting CheckBox

         if ( numberOfWhiteBlack != 0 &&
            whiteBlackCheckBox.Checked == false )
         {
            // keep white/black quantity at 0
            whiteBlackTextBox.Text = "0";

            MessageBox.Show(
               "Please check item you wish to purchase",
               "No Item Selected", MessageBoxButtons.OK,
               MessageBoxIcon.Exclamation );
         } // end if
         // display message if shipping information is not supplied
         else if ( string.IsNullOrEmpty( orderNumberTextBox.Text ) ||
            string.IsNullOrEmpty( nameTextBox.Text ) ||
            string.IsNullOrEmpty( addressLine1TextBox.Text ) ||
            string.IsNullOrEmpty( addressLine2TextBox.Text ) )
         {
            // display message in dialog
            MessageBox.Show(
               "Please fill out all information fields.",
               "Empty Fields", MessageBoxButtons.OK,
               MessageBoxIcon.Exclamation );
         } // end else if
         // display message if negative number entered
         else if ( numberOfWhiteBlack < 0 )
         {
            whiteBlackTextBox.Text = "0";
            MessageBox.Show(
               "Please enter a positive quantity",
               "Bad Input", MessageBoxButtons.OK,
               MessageBoxIcon.Exclamation );
         } // end else if
         else // calculate totals
         {
            CalculateAndDisplayTotals();
         } // end else
      } // end method whiteBlackTextBox_TextChanged

      private void redBlackTextBox_TextChanged( 
         object sender, EventArgs e )
      {
         // store quantity entered as int
         int numberOfRedBlack = Convert.ToInt32( redBlackTextBox.Text );

         // display message if user tries to enter a value
         // without selecting CheckBox

         if ( numberOfRedBlack != 0 && 
            redBlackCheckBox.Checked == false )
         {
            // keep white/black quantity at 0
            redBlackTextBox.Text = "0";

            MessageBox.Show(
               "Please check item you wish to purchase",
               "No Item Selected", MessageBoxButtons.OK,
               MessageBoxIcon.Exclamation );
         } // end if
         // display message if shipping information is not supplied
			else if ( string.IsNullOrEmpty( orderNumberTextBox.Text ) ||
				string.IsNullOrEmpty( nameTextBox.Text ) ||
				string.IsNullOrEmpty( addressLine1TextBox.Text ) ||
				string.IsNullOrEmpty( addressLine2TextBox.Text ) )
         {
            // display message in dialog
            MessageBox.Show(
               "Please fill out all information fields.",
               "Empty Fields", MessageBoxButtons.OK,
               MessageBoxIcon.Exclamation );
         } // end else if
         // display message if negative number entered
         else if ( numberOfRedBlack < 0 )
         {
            redBlackTextBox.Text = "0";
            MessageBox.Show(
               "Please enter a positive quantity",
               "Bad Input", MessageBoxButtons.OK,
               MessageBoxIcon.Exclamation );
         } // end else if
         else // calculate totals
         {
            CalculateAndDisplayTotals();
         } // end else
      } // end method redBlackTextBox_TextChanged

      private void blueBlackTextBox_TextChanged( 
         object sender, EventArgs e )
      {
         // store quantity entered as int
         int numberOfBlueBlack = Convert.ToInt32( 
            blueBlackTextBox.Text );

         // display message if user tries to enter a value
         // without selecting CheckBox
         if ( numberOfBlueBlack != 0 &&
            blueBlackCheckBox.Checked == false )
         {
            // keep white/black quantity at 0
            blueBlackTextBox.Text = "0";

            MessageBox.Show(
               "Please check item you wish to purchase",
               "No Item Selected", MessageBoxButtons.OK,
               MessageBoxIcon.Exclamation );
         } // end if
         // display message if shipping information is not supplied
			else if ( string.IsNullOrEmpty( orderNumberTextBox.Text ) ||
				string.IsNullOrEmpty( nameTextBox.Text ) ||
				string.IsNullOrEmpty( addressLine1TextBox.Text ) ||
				string.IsNullOrEmpty( addressLine2TextBox.Text ) )
         {
            // display message in dialog
            MessageBox.Show(
               "Please fill out all information fields.",
               "Empty Fields", MessageBoxButtons.OK,
               MessageBoxIcon.Exclamation );
         } // end else if
         // display message if negative number entered
         else if ( numberOfBlueBlack < 0 )
         {
            blueBlackTextBox.Text = "0";
            MessageBox.Show(
               "Please enter a positive quantity",
               "Bad Input", MessageBoxButtons.OK,
               MessageBoxIcon.Exclamation );
         } // end else if
         else // calculate totals
         {
            CalculateAndDisplayTotals();
         } // end else
      } // end method blueBlackTextBox_TextChanged

      // clear all fields
      private void clearButton_Click( object sender, EventArgs e )
      {
         // set all fields to their original values
         orderNumberTextBox.Text = "0";
         nameTextBox.Text = "Enter name here";
         addressLine1TextBox.Text = "Address Line 1";
         addressLine2TextBox.Text = "Address Line 2";
         cityStateZipTextBox.Text = "City, State, zip";
         whiteBlackTextBox.Text = "0";
         redBlackTextBox.Text = "0";
         blueBlackTextBox.Text = "0";
         whiteBlackLabel.Text = "$0.00";
         redBlackLabel.Text = "$0.00";
         blueBlackLabel.Text = "$0.00";
         subtotalLabel.Text = "$0.00";
         taxLabel.Text = "$0.00";
         shippingLabel.Text = "$0.00";
         totalLabel.Text = "$0.00";
         whiteBlackCheckBox.Checked = false;
         redBlackCheckBox.Checked = false;
         blueBlackCheckBox.Checked = false;
      } // end method clearButton_Click

      private void whiteBlackCheckBox_CheckedChanged(
         object sender, EventArgs e )
      {
         whiteBlackTextBox.Text = "0";
         whiteBlackLabel.Text = "0";
         CalculateAndDisplayTotals();
      } // end method whiteBlackCheckBox_CheckedChanged

      private void redBlackCheckBox_CheckedChanged(
         object sender, EventArgs e )
      {
         redBlackTextBox.Text = "0";
         redBlackLabel.Text = "0";
         CalculateAndDisplayTotals();
      } // end method redBlackCheckBox_CheckedChanged

      private void blueBlackCheckBox_CheckedChanged(
         object sender, EventArgs e )
      {
         blueBlackTextBox.Text = "0";
         blueBlackLabel.Text = "0";
         CalculateAndDisplayTotals();
      } // end method blueBlackCheckBox_CheckedChanged

      private void CalculateAndDisplayTotals()
      {
         // individual totals
         // total of white/black dice
         decimal whiteBlackTotals =
            Convert.ToDecimal( whiteBlackTextBox.Text ) * 6.25M;

         // total of red/black dice
         decimal redBlackTotals =
            Convert.ToDecimal( redBlackTextBox.Text ) * 5M;

         // total of blue/black dice
         decimal blueBlackTotals =
            Convert.ToDecimal( blueBlackTextBox.Text ) * 7.5M;

         // display individual totals
         whiteBlackLabel.Text = string.Format(
            "{0:C}", whiteBlackTotals );
         redBlackLabel.Text = string.Format( "{0:C}", redBlackTotals );
         blueBlackLabel.Text = string.Format( "{0:C}", blueBlackTotals );

         // subtotal, before tax and shipping
         decimal subtotal =
            whiteBlackTotals + redBlackTotals + blueBlackTotals;
         subtotalLabel.Text = string.Format( "{0:C}", subtotal );

         // calculate and display tax
         decimal tax = subtotal * 0.05M;
         taxLabel.Text = string.Format( "{0:C}", tax );

         // shipping: $1.50 for up to 20 items
         // free after 20 items
         int numberOfItems = Convert.ToInt32( whiteBlackTextBox.Text ) +
            Convert.ToInt32( redBlackTextBox.Text ) +
            Convert.ToInt32( blueBlackTextBox.Text );
         decimal shippingCost = 0M;

         if ( numberOfItems <= 20 && numberOfItems > 0 )
            shippingCost = 1.5M;

         // display shipping cost
         shippingLabel.Text = string.Format( "{0:C}", shippingCost );

         // calculate and display total charge
         decimal totalCharge = subtotal + tax + shippingCost;

         totalLabel.Text = string.Format( "{0:C}", totalCharge );
      } // end method CalculateAndDisplayTotals
   } // end class FuzzyDiceForm
} // end namespace FuzzyDice

/**************************************************************************
 * (C) Copyright 1992-2014 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/